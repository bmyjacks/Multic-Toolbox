# Multiple clipboard
## Usage method
### Before use
```
cd arm64
make
sudo dpkg -i Multic_Toolbox_$(Version).deb
```